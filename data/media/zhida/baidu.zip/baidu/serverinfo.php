<?php
$app_name = $_POST['app_name'];
$app_logo = $_POST['app_logo'];
$app_query = $_POST['app_query'];
$app_url = $_POST['custom_id'];
$app_desc = $_POST['app_desc'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$qua_cat_id = $_POST['qua_cat_id'];
$client_id = 'TALrs2iOU2wTQoNU6USHmPob';
$client_secret = 'OUxRVavHfCb0SUsrK2p9sSOgCrtChd8C';
//获取access_token
$gettoken = json_decode(file_get_contents("https://openapi.baidu.com/oauth/2.0/token?grant_type=client_credentials&client_id=$client_id&client_secret=$client_secret"));
if($gettoken->access_token){
    $access_token = $gettoken->access_token;
   //提交直达号信息
	$url = 'https://openapi.baidu.com/rest/2.0/devapi/v1/lightapp/query/create';
	$data = "access_token=$access_token&app_name=$app_name&app_logo=$app_logo&app_query=$app_query&app_url=$app_url&app_desc=$app_desc&email=$email&phone=$phone";
	if($qua_cat_id){
	   $data = $data."&qua_cat_id=$qua_cat_id";
	}
	//获取响应数据
	$resule     = json_decode(curlGet($url, 'post', $data));
	if($resule->app_id){
       var_dump('您的得到的直达号ID为'.$resule->app_id);die;
	}else{
	  
	  echo $resule->error_msg;exit;
	}
//var_dump($json);die;
}else{
   echo '出错了，请稍后再试';exit;
}
function curlGet($url, $method = 'get', $data = '')
	{
		$ch     = curl_init();
		$header = "Accept-Charset: utf-8";
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, strtoupper($method));
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
		curl_setopt($curl, CURLOPT_HTTPHEADER, $header);
		curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (compatible; MSIE 5.01; Windows NT 5.0)');
		curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
		curl_setopt($ch, CURLOPT_AUTOREFERER, 1);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		$temp = curl_exec($ch);
		return $temp;
	}

?>