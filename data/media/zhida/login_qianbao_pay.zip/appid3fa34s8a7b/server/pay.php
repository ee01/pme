<?php

require_once('bfb_sdk.php');
require_once('bfb_pay.cfg.php');

$bfb_sdk = new bfb_sdk();
$order_create_time = date("YmdHis");
$expire_time = date('YmdHis', strtotime('+2 day'));
$order_no = $order_create_time . sprintf ( '%06d', rand(0, 999999));
$good_name = $_POST['goods_name'];
$good_desc = $_POST['goods_desc'];
$goods_url = $_POST['goods_url']; 
$unit_amount = $_POST['unit_amount'];
$unit_count = $_POST['unit_count'];
$transport_amount = $_POST['transport_amount'];
$total_amount = $_POST['total_amount'];
$buyer_sp_username = $_COOKIE['bd_username'];
$return_url = $_POST['return_url'];
$page_url = $_POST['page_url'];
$pay_type = $_POST['pay_type'];
$bank_no = $_POST['bank_no'];
$extra = $_POST['extra'];

$good_name_utf8 = $good_name;

$good_name = iconv("UTF-8", "GBK", urldecode($good_name));

$params = array (
		'service_code' => sp_conf::BFB_PAY_INTERFACE_SERVICE_ID,
		'sp_no' => sp_conf::SP_NO,
		'order_create_time' => $order_create_time,
		'order_no' => $order_no,
		'goods_name' => $good_name,
		'goods_desc' => $good_desc,
		'goods_url' => $goods_url,
		'unit_amount' => $unit_amount,
		'unit_count' => $unit_count,
		'transport_amount' => $transport_amount,
		'total_amount' => $total_amount,
		'currency' => sp_conf::BFB_INTERFACE_CURRENTCY,
		'buyer_sp_username' => $buyer_sp_username,
		'return_url' => $return_url,
		'page_url' => $page_url,
		'pay_type' => $pay_type,
		'bank_no' => $bank_no,
		'expire_time' => $expire_time,
		'input_charset' => sp_conf::BFB_INTERFACE_ENCODING,
		'version' => sp_conf::BFB_INTERFACE_VERSION,
		'sign_method' => sp_conf::SIGN_METHOD_MD5,
		'extra' =>$extra
);


$order_url = $bfb_sdk->create_baifubao_pay_order_url($params, sp_conf::BFB_PAY_WAP_DIRECT_URL);
// $order_url = $bfb_sdk->create_baifubao_pay_order_url($params, sp_conf::BFB_PAY_DIRECT_LOGIN_URL);

?>

<!DOCTYPE html>
<html>
	<head>
		<title>订单确认</title>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<meta content="width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1,user-scalable=no" name="viewport" />
	    <meta name="apple-mobile-web-app-capable" content="yes" />

	    <script type="text/javascript" name="baidu-tc-cerfication" src="http://apps.bdimg.com/cloudaapi/lightapp.js#8e0d1e00e652c5c4685cbc81ed6b7020"></script>
	    <script type="text/javascript">window.bd && bd._qdc && bd._qdc.init({app_id: 'a88a95a5d02b12c8121e1d67'});</script>
		
		<script type="text/javascript">
			var is_clouda_loaded = false;
			clouda.lightapp('omsGUygW5MUTUBnA7YpmuK9L', function() {
				var options = {};
				options.onsuccess = function(data){
					
				};
				options.onfail = function(data){
				};
				clouda.mbaas.pay.init(<?php echo $params[sp_no]; ?>,options);

				is_clouda_loaded = true;
			});

			function dopay(orderInfo){ 
				if(is_clouda_loaded){
					var showdDialog = true; 
					var successCallback = function(resultText) {
						alert(resultText);
					};
					var errorCallback  = function(code){
						statcode = code.split(";")[0].split("{")[1].split("}")[0];

						if(statcode == 2){
							alert("您已取消支付");
						}
						alert("error dopay, errcode = " + code);
					};
					var options = {};
					options.orderInfo = orderInfo;
					options.showdDialog = showdDialog;
					options.onsuccess = successCallback;
					options.onfail = errorCallback;

					clouda.mbaas.pay.doPay(options);
				}				
			}
		</script>

	    <link rel="stylesheet" type="text/css" href="../css/style.css" />
	</head>

	<body >
		<p>用户名：<?php  echo  $buyer_sp_username;  ?></p> 
		<p>商品名：<?php  echo  $good_name_utf8;  ?></p> 
		<p>总价格：<?php  echo  $total_amount;  ?></p> 
		<button id="pay_confirm" onclick="dopay('<?php echo $order_url; ?>')">确认并支付</button>
	</body>
	
</html>