<?php
require_once('../sdk/BaiduApiClient.php');
require_once('../sdk/BaiduOAuth2.php');
require_once('../sdk/BaiduUtils.php');

//使用自己的API_key和secret_key替换clientId和clientSecret
$clientId = 'omsGUygW5MUTUBnA7YpmuK9L';
$clientSecret = '3s8ka7FzMFsH3NbX6sHR0anKoChy4FO4';
//使用的跳转页面替换redirectUri
$redirectUri = 'http://baiduloginpaydemo.duapp.com/server/redirect_uri.php';

$code = $_GET['code'];

$oauth = new BaiduOAuth2($clientId, $clientSecret);
$oauth->setRedirectUri($redirectUri);

$tokenArr = $oauth->getAccessTokenByAuthorizationCode($code);
if (is_array($tokenArr)) {
	// 换取token成功
	$accessToken = $tokenArr['access_token'];

	$expires_in = $tokenArr['expires_in'];
	// 获取用户信息
	$client = new BaiduApiClient($clientId, $accessToken);
	$infoArr = $client->api('/rest/2.0/passport/users/getInfo', 
				 array('fields' => 'userid,username'));
	if (is_array($infoArr)) {
		// 获取用户信息成功
		// 在这里将百度账号与应用自身的账号系统做联合登录处理，建议采取将百度账号暗绑到自身账号体系上
		// 然后将联合登录后生成的用户session的相关信息通过cookie返回到前端页面上
		// 为方便处理，这里将access_token和百度用户uid直接当session信息塞入cookie

		setcookie('bd_username', $infoArr['username'], strtotime('2030-1-1 12:00:00'), '/');
		setcookie('bd_uid', $infoArr['userid'], strtotime('2030-1-1 12:00:00'), '/');
		setcookie('bd_access_token', $accessToken, strtotime('2030-1-1 12:00:00'), '/');

		//查询用户是否享受过优惠
		$ch = curl_init("http://openapi.baidu.com/wallet/activity/info?activity_id=1&uid=" . $infoArr['userid']); 
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_BINARYTRANSFER, true) ; $output = curl_exec($ch) ; 
		$result = json_decode($output)->result; 

		setcookie('result', $result, strtotime('2030-1-1 12:00:00'), '/'); 
	}
}

?>

<!DOCTYPE html>
<html>
	<head></head>
	<body>
		<script>
			window.parent.onSuccess();
		</script>
	</body>
</html>
