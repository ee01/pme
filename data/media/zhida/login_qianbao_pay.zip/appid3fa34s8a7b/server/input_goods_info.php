
<!DOCTYPE html>
<html>
	<head>
		<title>订单填写页</title>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<meta content="width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1,user-scalable=no" name="viewport" />
	    <meta name="apple-mobile-web-app-capable" content="yes" />

	    <script type="text/javascript" name="baidu-tc-cerfication" src="http://apps.bdimg.com/cloudaapi/lightapp.js#8e0d1e00e652c5c4685cbc81ed6b7020"></script>
	    <script type="text/javascript">window.bd && bd._qdc && bd._qdc.init({app_id: 'a88a95a5d02b12c8121e1d67'});</script>

	    <link rel="stylesheet" type="text/css" href="../css/style.css" />

	    <script type="text/javascript">
	    	var is_clouda_loaded = false;
			clouda.lightapp('omsGUygW5MUTUBnA7YpmuK9L', function() {
				is_clouda_loaded = true;
			});

			//登陆成功后的处理函数
			function onSuccess(){
				clouda.mbaas.account.closeLoginDialog();

				result = <?php echo $_COOKIE['result'];  ?>;

				if(result == 1){
					//提交表单
					document.getElementById("goods_form").submit();
				}else{
					if(window.confirm('该账号已享受过优惠，请切换账号重新登陆购买')){
		                window.location.href = "http://"+window.location.hostname+"/server/login.php"; 
		                return true;
		            }else{
		                window.location.href = "http://"+window.location.hostname+"/index.html";
		                return false;
		            }
				}
			}

			//登陆页面点击“回退”后的处理函数
			function onFail() {
				alert('没有登录成功！');
			}

			function login(){
				if (is_clouda_loaded) {
					//使用轻应用登陆接口登陆
					clouda.mbaas.account.login({
						redirect_uri: 'http://'+window.location.hostname+'/server/redirect_uri.php',
						scope:'basic',
						// mobile: mobile,
						display: 'mobile',
						login_mode: 1,
						login_type:'sms',
						state:'hello_state_11111',
						onsuccess: onSuccess,
						onfail: onFail

					});
					// return true;
				}else{
					alert("正在加载js文件。。。。。。");
				}
			}
	    </script>
	</head>

	<body style="text-align: center;">
		<form action="pay.php" method="POST" id="goods_form" > 
			商品名称: <input type="text" name="goods_name" required="required" value="测试商品"/><br/>
			<input type="hidden" name="goods_desc" />
			<input type="hidden" name="goods_url" />
			<input type="hidden" name="unit_amount" />
			<input type="hidden" name="unit_count" />
			<input type="hidden" name="transport_amount" />
			总 金 额：<input type="text" name="total_amount" required="required" value="1"/><br/>
			<input type="hidden" name="buyer_sp_username" id="username"/>
			
			 <input style="display: none" type="text" name="return_url" id="return_url"  required="required" value="http://127.0.0.1/success.html" />
			<input type="hidden" name="page_url" />
			<select name="pay_type" required="required" style="display: none">
				<option value="2">网银支付（在百度钱包页面上选择银行，可以不登录百度钱包）</option> 
		   	</select>
			<input type="hidden" name="bank_no" />
			<input type="hidden" name="extra" />
			<!-- <input id="pay_submit"  type="submit" value="提交订单" /> -->
		</form>

		<button id="badiu_login" onclick="login()">提交订单</button>

	</body>
	
</html>